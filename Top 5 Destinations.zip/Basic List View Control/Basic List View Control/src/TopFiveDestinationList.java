import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

// new imports
// Added import statements for java.awt.Desktop, java.io.IOException, java.net.URI, and java.net.URISyntaxException.
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel();


        //Make updates to your top 5 list below. Import the new image files to resources directory.
        // Updated the addDestinationNameAndPicture method to include the image links for each destination.
        addDestinationNameAndPicture("<html><a href=\"https://commons.wikimedia.org/wiki/File:Z%C3%BCrich_Switzerland-Opera-Zurich-01.jpg\">1. Zurich, Switzerland (Explore the beauty of the Swiss Opera House)</a></html>", new ImageIcon(getClass().getResource("/resources/Zurich Switzerland Opera House.jpg"), "<html><a href=\"https://commons.wikimedia.org/wiki/File:Z%C3%BCrich_Switzerland-Opera-Zurich-01.jpg\">Click here to view top-selling travel package</a></html>"), "https://commons.wikimedia.org/wiki/File:Z%C3%BCrich_Switzerland-Opera-Zurich-01.jpg");// Image by CEphoto, Uwe Aranas (CC BY-SA 3.0)
        addDestinationNameAndPicture("<html><a href=\"https://commons.wikimedia.org/wiki/File:Palatul_%22Vulturul_Negru%22_Oradea.jpg/Oradea-travel-package\">2. Oradea, Romania (Wine and dine at the Black Eagle Restaurant)</a></html>", new ImageIcon(getClass().getResource("/resources/Black Eagle Oradea Romania.jpg"), "<html><a href=\"https://commons.wikimedia.org/wiki/File:Palatul_%22Vulturul_Negru%22_Oradea.jpg/Romania-travel-package\">Click here to view top-selling travel package</a></html>"), "https://commons.wikimedia.org/wiki/File:Palatul_%22Vulturul_Negru%22_Oradea.jpg");// Image by Silviunastase ([License])
        addDestinationNameAndPicture("<html><a href=\"https://commons.wikimedia.org/wiki/File:Hadrian%E2%80%99s_Gate,_Antalya,_Turkey_-_View_Feb_2022.jpg.jpg/Turkey-travel-package\">3. Antalya, Turkey (Explore Hadrian Gate)</a></html>", new ImageIcon(getClass().getResource("/resources/Hadrian Gate Antalya Turkey.jpg"), "<html><a href=\"https://commons.wikimedia.org/wiki/File:Hadrian%E2%80%99s_Gate,_Antalya,_Turkey_-_View_Feb_2022.jpg.jpg/Turkey-travel-package\">Click here to view top-selling travel package</a></html>"), "https://commons.wikimedia.org/wiki/File:Hadrian%E2%80%99s_Gate,_Antalya,_Turkey_-_View_Feb_2022.jpg");  // Image by Sharon Hahn Darlin ([License])
        addDestinationNameAndPicture("<html><a href=\"https://commons.wikimedia.org/wiki/File:Burj_Al_Arab_and_the_beach_(Pexels_823696).jpg.jpg/Dubai-travel-package\">4. Dubai (Feel like a Princess at the Burj Al Arab Hotel)</a></html>", new ImageIcon(getClass().getResource("/resources/Burj Al Arab Sea Dubai.jpg"), "<html><a href=\"https://commons.wikimedia.org/wiki/File:Burj_Al_Arab_and_the_beach_(Pexels_823696).jpg.jpg/Dubai-travel-package\">Click here to view top-selling travel package</a></html>"), "https://commons.wikimedia.org/wiki/File:Burj_Al_Arab_and_the_beach_(Pexels_823696).jpg"); // Image by Aleksandar Pasaric (License
        addDestinationNameAndPicture("<html><a href=\"https://commons.wikimedia.org/wiki/File:Marina_Bay_Sands,_Singapore_1.jpg.jpg/Singapore-travel-package\">5. Singapore (Explore the Marina Bay)</a></html>", new ImageIcon(getClass().getResource("/resources/Marina Bay Singapore.jpg"), "<html><a href=\"https://commons.wikimedia.org/wiki/File:Marina_Bay_Sands,_Singapore_1.jpg.jpg/Singapore-travel-package\">Click here to view top-selling travel package</a></html>"), "https://commons.wikimedia.org/wiki/File:Marina_Bay_Sands,_Singapore_1.jpg"); // Image by Ray in Manila (License)

        
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);
        JLabel nameLabel = new JLabel("Developer: Luminita Lanza");
        
     
        
        getContentPane().add(nameLabel, BorderLayout.NORTH);
        getContentPane().add(scrollPane,BorderLayout.CENTER);

        // Added a MouseListener to the TextAndIconListCellRenderer class that opens the destination link when the label is clicked.
        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);

        list.setCellRenderer(renderer);
        
        // // I added a CYAN as background to give esthetic look of ocean, and orange as color background to give it a nice contrast.
        list.setBackground(Color.CYAN);
        list.setSelectionBackground(Color.ORANGE);
        

        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    private void addDestinationNameAndPicture(String text, Icon icon, String link) {
        TextAndIcon tai = new TextAndIcon(text, icon, link);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;
    private String link;

    public TextAndIcon(String text, Icon icon, String link) {
        this.text = text;
        this.icon = icon;
        this.link = link;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }
  
    public String getLink() {
        return link;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
    
    public void setLink(String link) {
        this.link = link;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());
        
        this.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Desktop.getDesktop().browse(new URI(tai.getLink()));
				} catch (IOException | URISyntaxException ex) {
					ex.printStackTrace();
				}
			}
		});

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}