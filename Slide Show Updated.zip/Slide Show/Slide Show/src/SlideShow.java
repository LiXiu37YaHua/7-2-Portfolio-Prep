import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {

	//Declare Variables
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Initialize variables to empty objects
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		textPane = new JPanel();
		textPane.setBackground(Color.BLUE);
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		//Setup frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
		//logic to add each of the slides and text
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.SOUTH);
	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * Method to get the resized new images with links to the URLS
	 *
 * @param i The image index (1, 2, 3, ...)
 * @return The HTML string containing the image tag with the specified image and URL link
 */
	private String getResizeIcon(int i) {
		String image = ""; 
		if (i==1){
			// Replace "your_image_1.jpg" with the actual filename of your new image
			image = "<html><body><img width= '800' height='500' src='https://upload.wikimedia.org/wikipedia/commons/a/a9/Z%C3%BCrich_Switzerland-Opera-Zurich-01.jpg'/></html>";
			// Replace "your_url_for_image_1" with the URL link for the first image
		} else if (i==2){
			// Replace "your_image_2.jpg" with the actual filename of your new image
			image = "<html><body><img width= '800' height='500' src='https://upload.wikimedia.org/wikipedia/commons/2/2b/Palatul_%22Vulturul_Negru%22_Oradea.jpg'/></html>";
			// Replace "your_url_for_image_1" with the URL link for the second image
			// Replace "your_url_for_image_2" with the URL link for the second image
		} else if (i==3){
			// Replace "your_image_3.jpg" with the actual filename of your new image
			// Replace "your_url_for_image_1" with the URL link for the third image
			image = "<html><body><img width= '800' height='500' src='https://upload.wikimedia.org/wikipedia/commons/0/06/Hadrian%E2%80%99s_Gate%2C_Antalya%2C_Turkey_-_View_Feb_2022.jpg'/></html>";
		} else if (i==4){
			// Replace "your_image_4.jpg" with the actual filename of your new image
			// Replace "your_url_for_image_1" with the URL link for the fourth image
			image = "<html><body><img width= '800' height='500' src='https://upload.wikimedia.org/wikipedia/commons/5/5b/Burj_Al_Arab_and_the_beach_%28Pexels_823696%29.jpg'/></html>";
		} else if (i==5){
			// Replace "your_image_5.jpg" with the actual filename of your new image
			image = "<html><body><img width= '800' height='500' src='https://upload.wikimedia.org/wikipedia/commons/5/50/Marina_Bay_Sands%2C_Singapore_1.jpg'/></html>";
			// Replace "your_url_for_image_1" with the URL link for the fifth image
 
		}
		return image;
	}
	
	/**
	 * Method to get the text values
	 */
	private String getTextDescription(int i) {
		String text = ""; 
		if (i==1){
			text = "<html><body><font size='5'>#1 Zurich, Switzerland (Explore the beauty of the Swiss Opera House)</body></html>";
		} else if (i==2){
			text = "<html><body><font size='5'>#2 Oradea, Romania (Wine and dine at the Black Eagle Restaurant)</body></html>";
		} else if (i==3){
			text = "<html><body><font size='5'>#3 Antalya, Turkey (Explore Hadrian Gate)</body></html>";
		} else if (i==4){
			text = "<html><body><font size='5'>#4 Dubai (Feel like a Princess at the Burj Al Arab Hotel)</body></html>";
		} else if (i==5){
			text = "<html><body><font size='5'>#5 Singapore (Explore the Marina Bay)</body></html>";
		}
		return text;
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}